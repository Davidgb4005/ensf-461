#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include "parser.h"

#define BUFLEN 1024

//To Do: This base file has been provided to help you start the lab, you'll need to heavily modify it to implement all of the features

int main(void)
{
    char input[] = "/usr/bin/echo dev\ntest\ntest | grep dev";
    execution *cmd = parse_command(input);

    int prev_read = -1;

    while (cmd != NULL) {
        int pipe_fd[2];

        if (cmd->next_cmd != NULL) {
            pipe(pipe_fd);
        }

        pid_t pid = fork();

        if (pid == 0) {
            // Child

            if (prev_read != -1) {
                dup2(prev_read, STDIN_FILENO);
                close(prev_read);
            }

            if (cmd->next_cmd != NULL) {
                close(pipe_fd[0]);

                dup2(pipe_fd[1], STDOUT_FILENO);
                close(pipe_fd[1]);
            }

            execvp(cmd->cmd, cmd->args);

            perror("execvp");
            _exit(1);
        }


        if (prev_read != -1) {
            close(prev_read);
        }

        if (cmd->next_cmd != NULL) {
            close(pipe_fd[1]);
            prev_read = pipe_fd[0];
        }

        cmd = cmd->next_cmd;
    }

    while (wait(NULL) > 0) {
    }

    return 1;
}
