#include "parser.h"
#include "stdint.h"





#include <stdlib.h>
#include <string.h>
#define MAX_CMD_SIZE 64

execution * parse_command(char *input)
{
    execution *head = NULL;
    execution *tail = NULL;

    char *pipe_save;
    char *command = strtok_r(input, "|", &pipe_save);

    while (command != NULL) {

        execution *node = malloc(sizeof(execution));

        node->args = malloc(sizeof(char *) * MAX_CMD_SIZE);
        node->argc = 0;
        node->next_cmd = NULL;

        char *arg_save;
        char *token = strtok_r(command, " ", &arg_save);

        while (token != NULL) {
            node->args[node->argc] = token;
            node->argc++;

            token = strtok_r(NULL, " ", &arg_save);
        }

        node->args[node->argc] = NULL;
        node->cmd = node->args[0];

        if (head == NULL) {
            head = node;
        }
        else {
            tail->next_cmd = node;
        }

        tail = node;

    command = strtok_r(NULL, "|", &pipe_save);
    }

    return head;
}


